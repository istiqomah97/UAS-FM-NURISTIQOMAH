from django.forms import ModelForm
from dashboard.models import Barang, Transaksi, perpus
from django import forms

class FormBarang(ModelForm):
    class meta :
        model=Barang
        
        fields='__all__'

        Widgets = {
            'kodebrg': forms.TextInput ({'class':'form-control'}),
            'nama':forms.TextInput ({'class':'form-control'}),
            'stok': forms.TextInput ({'class':'form-control'}),
            'harga': forms.TextInput ({'class':'form-control'}),
            'link_gbr': forms.TextInput ({'class':'form-control'}),
            'jenis_id': forms.TextInput ({'class':'form-control'}),
        }


class FormTransaksi(ModelForm):
    class meta :
        model=Transaksi
        
        fields='__all__'

        Widgets = {
            'kodetrans': forms.TextInput ({'class':'form-control'}),
            'tgltrans':forms.TextInput ({'class':'form-control'}),
            'total': forms.TextInput ({'class':'form-control'}),
         
            
        }

class FormPerpus(ModelForm):
    class meta :
        model=perpus
        
        fields='__all__'

        Widgets = {
            'kodebuku': forms.TextInput ({'class':'form-control'}),
            'namabuku':forms.TextInput ({'class':'form-control'}),
            'penerbit': forms.TextInput ({'class':'form-control'}),
            'stok_buku': forms.TextInput ({'class':'form-control'}),
            'harga_buku': forms.TextInput ({'class':'form-control'}),
            
        }