from django.shortcuts import render,redirect
from dashboard.forms import FormBarang, FormTransaksi, FormPerpus
from dashboard.models import Barang, perpus, Transaksi
from django.contrib import messages
# Create your views here.


def tambah_barang(request):
    if request.POST:
        form= FormBarang(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Data Berhasil Ditambahkan")
            form = FormBarang()
            konteks = {
                'form':form,
            }
            return render(request, 'tambah_barang.html',konteks)
    else:
        form=FormBarang()
        konteks={
            'form':form,
        }
    return render(request, 'tambah_barang.html',konteks)

def produk(request):
    titelnya = "Produk"
    konteks = {
        'titel': titelnya,
    }
    return render(request, 'produk.html', konteks)


def Barang_view(request):
    barangs = Barang.objects.all()

    konteks = {
        'barangs': barangs,
    }
    return render(request, 'tampil_barang.html', konteks)


def transaksi_view(request):
    Transaksis = Transaksi.objects.all()
    konteks = {
        'Transaksis': Transaksis,
    }
    return render(request, 'Transaksi.html', konteks)

def tambah_transaksi(request):
    if request.POST:
        form= FormTransaksi(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Data Berhasil Ditambahkan")
            form = FormTransaksi()
            konteks = {
                'form':form,
            }
            return render(request, 'tambah_transaksi.html',konteks)
    else:
        form=FormTransaksi()
        konteks={
            'form':form,
        }
    return render(request, 'tambah_transaksi.html',konteks)

def ubah_transaksi(request,id_transaksi):
    transaksis=Transaksi.objects.get(id=id_transaksi)
    if request.POST:
        form=FormTransaksi(request.POST,instance=transaksis)
        if form.is_valid():
            form.save()
            messages.success(request, "Data Berhasil Diubah")
            return redirect('ubah_transaksi', id_transaksi=id_transaksi)
    else:
        form=FormTransaksi(instance=transaksis)
        konteks = {
            'form':form,
            'transaksis':transaksis,
        }
    return render(request, 'ubah_transaksi.html',konteks)

def hapus_transaksi(request,id_transaksi):
    transaksis=Transaksi.objects.filter(id=id_transaksi)
    transaksis.delete()
    messages.success(request, "Data Terhapus")
    return redirect('transaksi')


def perpus_view(request):
    Perpuss = perpus.objects.all()
    konteks = {
        'Perpuss': Perpuss,
    }
    return render(request, 'perpus.html', konteks)

def tambah_perpus(request):
    if request.POST:
        form= FormPerpus(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Data Berhasil Ditambahkan")
            form = FormPerpus()
            konteks = {
                'form':form,
            }
            return render(request, 'tambah_perpus.html',konteks)
    else:
        form=FormPerpus()
        konteks={
            'form':form,
        }
    return render(request, 'tambah_perpus.html',konteks)

def ubah_perpus(request,id_perpus):
    perpuss=Perpus.objects.get(id=id_perpus)
    if request.POST:
        form=FormPerpus(request.POST,instance=perpuss)
        if form.is_valid():
            form.save()
            messages.success(request, "Data Berhasil Diubah")
            return redirect('ubah_perpus', id_perpus=id_perpus)
    else:
        form=FormPerpus(instance=perpuss)
        konteks = {
            'form':form,
            'perpuss':perpuss,
        }
    return render(request, 'ubah_perpus.html',konteks)

def hapus_perpus(request,id_perpus):
    perpuss=Perpus.objects.filter(id=id_transaksi)
    perpuss.delete()
    messages.success(request, "Data Terhapus")
    return redirect('perpus')

def ubah_brg(request,id_barang):
    barangs=Barang.objects.get(id=id_barang)
    if request.POST:
        form=FormBarang(request.POST,instance=barangs)
        if form.is_valid():
            form.save()
            messages.success(request,"Data Berhasil diubah")
            return redirect('ubah_brg',id_barang=id_barang)
    else:
        form=FormBarang(instance=barangs)
    konteks = {
        'form':form,
        'barangs':barangs
    }
    return render(request,'ubah_brg.html',konteks)

def hapus_brg(request,id_barang):
    Barangs=barang.objects.filter(id=id_barang)
    barangs.delete()
    message.success(request,"Data Terhapus")
    return redirect('Vbrg')