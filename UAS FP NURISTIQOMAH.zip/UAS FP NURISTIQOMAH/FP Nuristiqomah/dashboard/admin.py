from django.contrib import admin

# Register your models here.
from .models import Barang, Transaksi, Jenis, perpus, pinjam_buku


class kolombarang(admin.ModelAdmin):
    list_display = ['kodebrg', 'nama', 'stok', 'harga', 'link_gbr', 'Jenis_id']
    search_fields = ['kodebrg', 'nama']
    list_filter = ('Jenis_id',)
    list_per_page = 3


class kolomperpus(admin.ModelAdmin):
    list_display = ['kodebuku', 'namabuku',
                    'penerbit', 'stokbuku', 'hargabuku']

class kolompinjam(admin.ModelAdmin):
    list_display = ['kodebuku', 'nama', 'penerbit', 'tanggal_pinjam', 'tanggal_pengembalian',]
    search_fields = ['kodebuku', 'nama']
    list_filter = ('penerbit',)
    list_per_page = 3


admin.site.register(Barang, kolombarang)
admin.site.register(Transaksi)
admin.site.register(perpus, kolomperpus)
admin.site.register(Jenis)
