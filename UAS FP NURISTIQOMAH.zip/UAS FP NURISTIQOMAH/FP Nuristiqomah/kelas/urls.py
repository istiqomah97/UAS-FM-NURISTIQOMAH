import imp
from django.contrib import admin
from django.urls import path
from django.http import HttpResponse
from django.shortcuts import render
from dashboard.views import produk
from dashboard.views import produk, tambah_barang, Barang_view, transaksi_view, perpus_view, tambah_transaksi
from dashboard.views import*
from dashboard.views import Barang_view, ubah_transaksi, hapus_transaksi, ubah_perpus, hapus_perpus

path ('ubah/<int:id_barang>',ubah_brg,name='ubah_brg'),

def coba1(request):
    return HttpResponse('Selamat Sore...')


def coba2(request):
    titelnya = "Home"
    konteks = {
        'titel': titelnya,
    }
    return render(request, 'index.html', konteks)


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', coba2, name='home'),
    path('produk/', produk, name='produk'),
    path('addbrg/', tambah_barang, name='add_brg'),
    path('brgview/', Barang_view, name='tampil_brg'),
    path('transaksi/', transaksi_view, name='transaksi'),
    path('perpus/', perpus_view, name='perpus'),
    path('ubah/<int:id_barang>',ubah_brg,name='ubah_brg'),
    path('hapus/<int:id_barang>',hapus_brg,name='hapus_brg'),
    path('addtransaksi/',tambah_transaksi, name="add_transaksi"),
    path('ubah/<int:id_transaksi>',ubah_transaksi,name='ubah_transaksi'),
    path('hapus/<int:id_transaksi>',hapus_transaksi,name='hapus_transaksi'),
    path('addperpus/',tambah_perpus, name="add_perpus"),
    path('ubah/<int:id_perpus>',ubah_perpus,name='ubah_perpus'),
    path('buang/<int:id_perpus>',hapus_perpus,name='hapus_perpus'),
    path('vbrg/',Barang_view, name='vbrg'),
]
